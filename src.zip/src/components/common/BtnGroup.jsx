import React from "react";

const BtnGroup = ({ children, className }) => {
  return <div className={className}>{children}</div>;
};

export default BtnGroup;
