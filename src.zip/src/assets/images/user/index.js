import mainLogo from "./logo.png";
import appleStore from "./apple-store.png";
import googleplay from "./google-play.png";
import bannner from "./banner.png";
import video from "./video.jpg";
import card1 from "./card1.jpg";
import tv from "./tv.png";
import ecobank from "./ecobank.png";
import orange from "./orange.png";
import iphone from "./iphone.png";
import android from "./android.png";
import footerlogo from "./footerLogo.png";
import team1 from "./team1.png";
import bgimg from "./bg-img.png";
import virtualworld from "./virtual_world.png";
import video1 from "./popular-1.jpg";
import video2 from "./popular-2.jpg";
import video3 from "./popular-3.jpg";
import video4 from "./popular-4.jpg";
import video5 from "./popular-5.jpg";
import video_homescreen from "./video_homescreen.png";
import video_player_thumbnail from "./video_player_thumbnail.png";

export {
  mainLogo,
  appleStore,
  googleplay,
  bannner,
  video,
  card1,
  tv,
  ecobank,
  orange,
  android,
  iphone,
  footerlogo,
  team1,
  bgimg,
  virtualworld,
  video1,
  video2,
  video3,
  video4,
  video5,
  video_homescreen,
  video_player_thumbnail,
};
