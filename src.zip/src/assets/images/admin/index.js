import logo from './logo.png';
import video_card from './video_card.jpg';
import demopic from './demo-pic.png';
import demopic2 from './demo-pic2.png';
import program from './program.jpg'
import thumbnail from './thumbnail.png'
import video from './video.png'
import burger from './burger.png'
export {logo, video_card, demopic, demopic2, program, thumbnail, video, burger};