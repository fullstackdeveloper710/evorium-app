import { English } from "./english";
import { Español } from "./Español";
import { Français } from "./Français";

export { English, Español, Français };
