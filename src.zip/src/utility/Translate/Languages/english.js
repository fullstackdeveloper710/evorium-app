export const English = {
  language: "language",
  home: "home",
  programs: "programs",
  login: "login",
  logout: "logout",
  usrHomeHeading: "Learn crypto from beginner to Pro",
  usrHomeSubHeading: `The Screeno ecosystem is designed to help you generate profit.
    Set up complete sales and marketing funnels with ease using
    the Screeno`,
  tryForFree: "Try for Free",
  platformHead: "All-in-one platform",
  platformSubHead: `You take care of the video quality and we take care of
  everything else`,
  uploadAndOrganize: `Upload & Organize`,
  uploaqInBulk:
    "Upload in bulk, organize content in categories, add custom filters & upload extras.",
  monetization: "Monetization",
  monetizationSub:
    "Offer subscriptions or one-time purchases. Accept credit cards & PayPal.",
  streamOnDemand: "Stream On-Demand",
  streamOnDemandSub: `Showcase your content in a beautiful on-demand video catalog.`,
  mostPopular: "most popular",
  viewAll: "View All",
  loadMore: "Load more",
  starTeam: "Our Star Team",
  starTeamDescription:"Consistent quality and experience across all platforms and devices.",
  starTeamName:"Name",
  starTeamSurname:"Surname",
  starTeamContent:" Showcase your content in a beautiful on-demand video catalog.",
  ourPartners:"Our Partners",
  ourPartnersDescription:"Consistent quality and experience across all platforms and devices.",
  roadmap:"Roadmap",
  step1:"Step 1",
  step1point1:"Token creation & smart contract development during 2023",
  step1point2:"Website launch",
  step1point3:"Community building and marketing campaign",
  step1point4:"Token creation and smart contract development",
  step1point5:"Website launch",
  step2:"Step 2",
  step3:"Step 3",
  step4:"Step 4",
// footer
navigation:"NAVIGATION",
AllProducts:"All Products",
ValueKits:"Value Kits",
Bestsellers:"Bestsellers",
PreviousCollection:"Previous Collection",

aboutus:"ABOUT US?",
FAQ:"FAQ",
TrackOrder:"Track Your Order",
Quadplay:"Quadplay",
ContactUs:"Contact Us",


evoriumfam:"EVORIUM FAM'",
About:"About us",
Rewards:"Rewards & Loyalty",
Affiliation:"Affiliation Club",
MyAccount:"My Account",

legalinfo:"LEGAL INFO",
terms:" Terms of Service",
privacy:" Privacy Policy ",
refunds:"Refunds Policy",
previouscollection:"Previous Collection",










};
